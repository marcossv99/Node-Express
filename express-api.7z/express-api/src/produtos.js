  const express = require('express');
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  let products = [];

  // Routes
  app.post('/products', (req, res) => {
    const { name, price } = req.body;
    const id = products.length + 1;
    const newProduct = { id, name, price };
    products.push(newProduct);
    res.status(201).json(newProduct);
  });

  app.get('/products', (req, res) => {
    res.json(products);
  });

  app.get('/products/:id', (req, res) => {
    const { id } = req.params;
    const product = products.find(p => p.id == id);
    if (product) {
      res.json(product);
    } else {
      res.status(404).json({ message: 'Produto nao encontrado' });
    }
  });

  app.put('/products/:id', (req, res) => {
    const { id } = req.params;
    const { name, price } = req.body;
    const productIndex = products.findIndex(p => p.id == id);
    if (productIndex > -1) {
      products[productIndex] = { id: Number(id), name, price };
      res.json(products[productIndex]);
    } else {
      res.status(404).json({ message: 'Produto nao encontrado' });
    }
  });

  app.delete('/products/:id', (req, res) => {
    const { id } = req.params;
    const productIndex = products.findIndex(p => p.id == id);
    if (productIndex > -1) {
      products.splice(productIndex, 1);
      res.status(204).send();
    } else {
      res.status(404).json({ message: 'Produto nao encontrado' });
    }
  });

  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
