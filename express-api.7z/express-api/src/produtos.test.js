const request = require('supertest');
const express = require('express');

const app = express();
app.use(express.json());

let products = [];

app.post('/products', (req, res) => {
  const { name, price } = req.body;
  const id = products.length + 1;
  const newProduct = { id, name, price };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

app.get('/products', (req, res) => {
  res.json(products);
});

app.get('/products/:id', (req, res) => {
  const { id } = req.params;
  const product = products.find(p => p.id == id);
  if (product) {
    res.json(product);
  } else {
    res.status(404).json({ message: 'Produto nao encontrado' });
  }
});

app.put('/products/:id', (req, res) => {
  const { id } = req.params;
  const { name, price } = req.body;
  const productIndex = products.findIndex(p => p.id == id);
  if (productIndex > -1) {
    products[productIndex] = { id: Number(id), name, price };
    res.json(products[productIndex]);
  } else {
    res.status(404).json({ message: 'Produto nao encontrado' });
  }
});

app.delete('/products/:id', (req, res) => {
  const { id } = req.params;
  const productIndex = products.findIndex(p => p.id == id);
  if (productIndex > -1) {
    products.splice(productIndex, 1);
    res.status(204).send();
  } else {
    res.status(404).json({ message: 'Produto nao encontrado' });
  }
});

describe('Products API', () => {
  beforeEach(() => {
    products = [];
  });

  it('deverá criar um novo produto', async () => {
    const response = await request(app)
      .post('/products')
      .send({ name: 'Product 1', price: 100 });
    expect(response.status).toBe(201);
    expect(response.body.name).toBe('Product 1');
    expect(response.body.price).toBe(100);
  });

  it('deverá listar todos os produtos', async () => {
    await request(app)
      .post('/products')
      .send({ name: 'Product 1', price: 100 });
    const response = await request(app).get('/products');
    expect(response.status).toBe(200);
    expect(response.body.length).toBe(1);
  });

  it('deverá retornar um produto com id especifico', async () => {
    const product = await request(app)
      .post('/products')
      .send({ name: 'Product 1', price: 100 });
    const response = await request(app).get(`/products/${product.body.id}`);
    expect(response.status).toBe(200);
    expect(response.body.name).toBe('Product 1');
  });

  it('deverá atualizar um produto com um id existente', async () => {
    const product = await request(app)
      .post('/products')
      .send({ name: 'Product 1', price: 100 });
    const response = await request(app)
      .put(`/products/${product.body.id}`)
      .send({ name: 'Updated Product', price: 150 });
    expect(response.status).toBe(200);
    expect(response.body.name).toBe('Updated Product');
  });

  it('deverá deletar um produto com id especifico', async () => {
    const product = await request(app)
      .post('/products')
      .send({ name: 'Product 1', price: 100 });
    const response = await request(app).delete(`/products/${product.body.id}`);
    expect(response.status).toBe(204);
    const productsResponse = await request(app).get('/products');
    expect(productsResponse.body.length).toBe(0);
  });
});

module.exports = app;
